package com.sjnc.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
