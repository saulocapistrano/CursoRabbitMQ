package com.sjnc.productor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductorApplicationTests {

	@Test
	void contextLoads() {
	}

}
